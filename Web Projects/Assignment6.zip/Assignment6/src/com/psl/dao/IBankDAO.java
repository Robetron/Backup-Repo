package com.psl.dao;

import java.util.List;
import com.psl.beans.Transaction;

public interface IBankDAO {
	void newTransaction(Transaction t);

	List<Transaction> creatMiniStatement(String accountNumber);

	double fetchBalance(String accountNumber);

}
