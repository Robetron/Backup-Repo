package com.psl.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.psl.beans.Donor;


//extend JdbcDaoSupport 
//then instead of using template use the method getJdbcTemplate()

@Repository
public class DonorDAOImpl implements IDonorDAO {

	@Autowired
	private JdbcTemplate template;

	public DonorDAOImpl() {
	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public void createDonor(Donor e) {
		String sql = "insert into donor values(" + e.getId() + ",'"
				+ e.getName() + "','" + e.getBloodGroup() + "')";
		System.out.println(sql);
		this.template.update(sql);
	}

	@Override
	public List<Donor> getAllDonors() {
		return this.template.query("select * from donor",
				new RowMapper<Donor>() {

					@Override
					public Donor mapRow(ResultSet rs, int rowNo)
							throws SQLException {
						Donor e = new Donor();
						e.setId(rs.getInt("id"));
						e.setName(rs.getString("name"));
						e.setBloodGroup(rs.getString("blood_group"));
						return e;
					}
				});
	}

	@Override
	public void updateDonor(int id, String name) {
		String sql = "update donor set name='" + name + "' where id=" + id;
		System.out.println("Update :" + sql);
		this.template.update(sql);
	}

	@Override
	public void deleteDonor(int id) {
		String sql = "delete from donor where id=" + id;
		System.out.println("Delete:" + sql);
		this.template.update(sql);
	}

	@Override
	public String getDonorDetails(int id) {
		return this.template.queryForObject("select blood_group from donor where id="+id, String.class);
	}

}
