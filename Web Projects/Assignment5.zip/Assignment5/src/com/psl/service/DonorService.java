package com.psl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.psl.beans.Donor;
import com.psl.dao.IDonorDAO;

@Service
public class DonorService {

	@Autowired
	private IDonorDAO dao;

	public DonorService() {
	}

	public IDonorDAO getDao() {
		return dao;
	}

	public void setDao(IDonorDAO dao) {
		this.dao = dao;
	}

	public void createDonor(Donor e) {
		this.dao.createDonor(e);
	}
	
	public void deleteDonor(int id){
		this.dao.deleteDonor(id);
	}
	
	public void updateDonor(int id,String name){
		this.dao.updateDonor(id, name);
	}
	
	public List<Donor> getAllDonors(){
		return dao.getAllDonors();
	}
	
	public String getDonorDetails(int id){
		return dao.getDonorDetails(id);
	}
}
