package com.psl.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.psl.beans.Admin;
import com.psl.service.AdminService;

@Controller
//@RequestMapping(value="/")
public class AdminController {

	@Autowired
	private AdminService service;

	@RequestMapping(value="/",method=RequestMethod.GET)
	public String showHomePage(Model model){
		System.out.println("in Admin controller.showHomePage()");
		
		model.addAttribute("admin", new Admin());
		return "admin";
	}
	
	@RequestMapping(value="/",method=RequestMethod.POST)
	public String register(Model model,@Valid @ModelAttribute Admin admin){
		System.out.println("Admin "+admin.getUsername());

		if(service.auth(admin.getUsername(), admin.getPassword())){
			System.out.println("redirecting");
			return "redirect:/donor/home";
		}
		System.out.println("Auth failed");
		return "admin";
	}
}
