package com.psl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {
	public static void main(String[] args) throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
		Train train = (Train) context.getBean("train");
		train.departFromSource("Pune", "10am");
		train.arriveAtDestination("Mumbai", "1pm");
	}
}