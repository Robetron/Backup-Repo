package com.psl;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class TicketCollector {
	@Pointcut(value = "execution(* com.psl.Train.departFromSource(String,String)) && args(source,time)")
	public void pc1(String source, String time) {

	}

	@Pointcut(value = "execution(* com.psl.Train.arriveAtDestination(String,String)) && args(destination,time)")
	public void pc2(String destination, String time) {

	}

	private void entersTrain() {
		System.out.println("TC enters the Train.");
	}

	private void exitsTrain() {
		System.out.println("TC exits the Train.");
	}

	private void checksTickets() {
		System.out.println("TC checks Passengers tickets.");
		collectsFine();
	}

	private void collectsFine() {
		System.out.println("TC collects fine from Defaulters.");
	}

	private void printsPassengerList() {
		System.out.println("TC prints passenger list.");
	}

	private void verifyPassengerList() {
		System.out.println("TC verifies passenger list.");
	}

	private void depositFine() {
		System.out.println("TC deposits fine at station.");
	}
	private void goesHome() {
		System.out.println("TC goes home.");
	}
	@Around(value = "pc1(source, time)")
	public void startRounds(ProceedingJoinPoint joinPoint, String source,
			String time) {
		// Before
		printsPassengerList();
		entersTrain();
		// During
		try {
			joinPoint.proceed(); // Calling Train.depart()
			System.out.println("Train running...");
		} catch (Throwable e) {
			e.printStackTrace();
			System.out.println("Train Delayed at " + source+".");
		}
		// After
		checksTickets();
	}

	@Around(value = "pc2(destination, time)")
	public void endRounds(ProceedingJoinPoint joinPoint, String destination,
			String time) {
		// Before
		verifyPassengerList();
		// During
		try {
			joinPoint.proceed(); // Calling Performer.perform()
		} catch (Throwable e) {
			e.printStackTrace();
			System.out.println("Train Delayed at " + destination+".");
		}
		// After
		exitsTrain();
		depositFine();
		goesHome();
	}
}