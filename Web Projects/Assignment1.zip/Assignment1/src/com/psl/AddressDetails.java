package com.psl;

public class AddressDetails {
	private String city, state, zip, landmark;

	public AddressDetails() {
	}

	public AddressDetails(String city, String state, String zip, String landmark) {
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.landmark = landmark;
	}

	public String getCity() {
		return city;
	}

	@Override
	public String toString() {
		return "AddressDetails [city=" + city + ", state=" + state + ", zip="
				+ zip + ", landmark=" + landmark + "]";
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
}
