package com.psl.dao;

import java.util.List;

import com.psl.beans.Donor;

public interface IDonorDAO {

	void createDonor(Donor e);

	List<Donor> getAllDonors();

	void updateDonor(int id, String name);

	void deleteDonor(int id);
	
	String getDonorDetails(int id);
}
