package com.psl.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AdminDAOImpl implements IAdminDAO {

	@Autowired
	private JdbcTemplate template;
	
	@Override
	public boolean authenticate(String username, String password) {
		System.out.println("Authenticating");
		String dbPassword=this.template.queryForObject("select password from admin where username='"+username+"'", String.class);
		if(dbPassword.equals(password)){
			return true;
		}
		return false;
	}

}
