package com.psl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.psl.dao.IAdminDAO;

@Service
public class AdminService {

	@Autowired
	private IAdminDAO dao;

	public IAdminDAO getDao() {
		return dao;
	}

	public void setDao(IAdminDAO dao) {
		this.dao = dao;
	}
	
	public boolean auth(String user,String pwd){
		return this.dao.authenticate(user, pwd);
	}
}
