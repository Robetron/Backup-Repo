package com.psl.beans;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Donor {

	@Min(value=1)
	@Max(value=9999)
	private int id;
	
	@Size(min=2,max=15,message="Name should be between 2-15 characters long")
	private String name;
	
	@Pattern(regexp="^(A|B|AB|O)[+-]$", message="Please enter a valid blood group")
	private String bloodGroup;
	
	public Donor() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	@Override
	public String toString() {
		return "Donor [id=" + id + ", name=" + name + ", bloodGroup="
				+ bloodGroup + "]";
	}

	
}
