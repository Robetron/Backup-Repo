package com.psl.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.psl.beans.Donor;
import com.psl.service.DonorService;


//what your url looks like 
// https://localhost:8080/SpringMVCDemo/home
//servlet context path https://localhost:8080/SpringMVCDemo
//url pattern /home

@Controller
@RequestMapping(value="/donor")
public class DonorController {

	@Autowired
	private DonorService service;
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String showHomePage(Model model){
		System.out.println("in Donor controller.showHomePage()");
		
		model.addAttribute("donor", new Donor());
		List<Donor> le= service.getAllDonors();
		model.addAttribute("list", le);
		return "home";
	}
	
	@RequestMapping(value="/{donorName}",method=RequestMethod.GET)
	public String showEmpPage(Model model,@PathVariable String donorName,@RequestParam(required=false) String id){
		System.out.println("in"+donorName+" controller.showHomePage()");
		
		model.addAttribute("name", donorName);
		model.addAttribute("bloodGroup", service.getDonorDetails(Integer.parseInt(id)));
		return "donor-details";
	}
	
	@RequestMapping(value="/home",method=RequestMethod.POST)
	public String register(Model model,@Valid @ModelAttribute Donor donor,BindingResult result){
		System.out.println("Donor "+donor.toString());
		if(result.hasErrors()){
			return "home";
		}
		
		service.createDonor(donor);
		return "redirect:/donor/home";
	}
}
