package com.psl;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	public static void main(String[] args) {
		// Initialize Spring Container
		
		// 1) If file is on Server
		// ApplicationContext context = new FileSystemXmlApplicationContext("C:\Users\Administrator\Desktop\VSR\Web Projects\HelloWorld\src\SpringConfig.xml");
				
		// 2) If file isn't in Project Folder
		// ApplicationContext context = new XmlWebApplicationContext("SpringConfig.xml");
		
		// 3) If file is in Project Folder
		//ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
		
		Ticket t = (Ticket) context.getBean("ticket");
		System.out.println(t.toString());
		
		//Simulates Container Shutdown
		context.registerShutdownHook();
	}
}
